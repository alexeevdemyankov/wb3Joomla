<?php
function wb3_faico($fieldKey, $field, $fieldData)
{
    return '<i class="' . $fieldData[$field->wb3_field] . '"></i>';
}
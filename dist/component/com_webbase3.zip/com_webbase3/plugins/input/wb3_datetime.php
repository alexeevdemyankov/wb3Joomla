<?php
function wb3_datetime($field, $fieldData)
{
    $input = '
  
        <input 
            type="text" 
            class="form-control form-control-sm" 
            id="' . $field->wb3_field . '" 
            name="' . $field->wb3_field . '" 
            placeholder="' . JText::_('COM_WEBBASE_INPUT_PLACEHOLDER') . ' ' . $field->wb3_title . '" 
            value="' . $fieldData[$field->wb3_field] . '">                   
    ';


    $script = " 
    <script>
    jQuery(document).ready(function () {
        jQuery('#" . $field->wb3_field . "').datepicker({timeFormat: 'hh:ii:00', timepicker: true, dateFormat: 'yyyy-mm-dd',});
        jQuery('#" . $field->wb3_field . "').data('datepicker');
        jQuery('.datepicker').css('z-index', 3000);
    });
    </script>
    ";


    $return = '
        <div class="form-group">
            <label>' . $field->wb3_title . ':</label>
            <div class="input-group">                
                ' . $input . '        
            </div>
        </div>'.$script;


    return $return;

}
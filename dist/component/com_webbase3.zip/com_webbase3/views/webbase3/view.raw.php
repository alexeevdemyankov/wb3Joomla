<?php

defined('_JEXEC') or die;

class Webbase3ViewWebbase3 extends JViewLegacy
{
    public function display($tpl = null)
    {
        $tpl = 'blank';

        parent::display($tpl);
    }
}

<?php

class Webbase3ModelWb3_copy extends JModelList
{


}
<?php

class Webbase3ModelWb3_del extends JModelList
{




}
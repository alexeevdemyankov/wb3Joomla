<?php

class Webbase3ModelWebbase3 extends JModelList
{





}
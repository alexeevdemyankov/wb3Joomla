<?php

class Webbase3ModelWb3_select2 extends JModelList
{
    function select2($jinput)
    {
        $base = $jinput->get('base', '', '');
        $table = $jinput->get('table', '', '');
        $field = $jinput->get('field', '', '');
        $fieldLike = $jinput->get('field', '', '');
        $key = $jinput->get('key', '', '');
        $q = $jinput->get('q', '', '');
        $concat = $jinput->get('concat', '', '');

        $currentTable = ($base) ? '`' . $base . '`.`' . $table . '`' : '`' . $table . '`';


        $q = str_replace('*', '%', $q);

        if ($concat == 1):$field = "CONCAT('['," . $key . ",'] '," . $field . ")";endif;
        $query = "select $key,$field from $currentTable where `$fieldLike` like '" . $q . "%' or $key like  '" . $q . "%' limit 50";

        $items = JFactory::getDbo()->setQuery($query)->loadRowList();

        $json[0] = ['id' => 'null', 'text' => 'Нет'];
        foreach ($items as $item) {
            $json[] = ['id' => $item[0], 'text' => $item[1]];
        }
        return json_encode($json);
    }
}

